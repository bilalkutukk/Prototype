using UnityEngine;

[CreateAssetMenu(fileName = "NewCard", menuName = "CardGame/Card")]
public class CardData : ScriptableObject
{
    public string cardName;
    public Sprite artwork;
    public int value;

    public RectTransform cardRect; // Reference to the card's transform in the UI
    public GameObject instanceGO; // Reference to the card's transform in the UI
}
